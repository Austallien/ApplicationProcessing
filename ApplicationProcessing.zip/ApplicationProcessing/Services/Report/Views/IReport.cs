﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationProcessing.Services.Report.Views
{
    internal interface IReport
    {
        public bool Create();
    }
}